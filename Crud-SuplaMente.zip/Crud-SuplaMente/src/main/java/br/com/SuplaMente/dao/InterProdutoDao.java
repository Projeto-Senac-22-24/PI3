package br.com.SuplaMente.dao;

import br.com.SuplaMente.modelos.Categorias;
import br.com.SuplaMente.modelos.Produto;

import java.util.List;
import java.util.Optional;

public interface InterProdutoDao {
    Produto save(Produto produto);
    Produto update(Produto produto);
    void deleta(long id);
  //  List<Produto> findAll();// ira devolver todos os produtos
  //  Optional<Produto> findById(long id);// ira buscar um produto pelo id
   // Optional<Produto> findByString(String Nome);
   // List<Produto> findByCategoria(Categorias categoria);
}
