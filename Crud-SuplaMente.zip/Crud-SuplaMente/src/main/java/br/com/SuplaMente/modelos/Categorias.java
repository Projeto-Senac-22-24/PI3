package br.com.SuplaMente.modelos;

public enum Categorias {


}
